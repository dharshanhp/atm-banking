
package bankmanagementsystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import com.toedter.calendar.*;

public class SignupOne extends JFrame implements ActionListener {
    JLabel formno, pincode, state, city, address, personalDetails, marital, name, fname, dob, gender, email;
    JTextField nameTextField, addressTextField, emailTextField, cityTextField, stateTextField, fnameTextField, pincodeTextField;
    long random;
    JDateChooser dateChooser;
    JRadioButton male, female, married, unmarried, other;
    ButtonGroup gendergroup, Maritalgroup;
    JButton next;
    Image backgroundImage;

    SignupOne() {
        setTitle("Signup Form - Page 1");
        setSize(850, 800);
        setLocation(350, 10);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Load the background image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/pexels-liliana-drew-8554384.jpg"));
        backgroundImage = i1.getImage();

        // Create a custom JPanel with overridden paintComponent
        JPanel backgroundPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        backgroundPanel.setLayout(null);
        add(backgroundPanel);

        // Generate random application form number
        Random ran = new Random();
        random = Math.abs(ran.nextLong() % 9000L + 1000L);

        // UI Elements
        formno = new JLabel("APPLICATION FORM NO. " + random);
        formno.setFont(new Font("Raleway", Font.BOLD, 38));
        formno.setForeground(Color.WHITE);
        formno.setBounds(140, 20, 700, 40);
        backgroundPanel.add(formno);

        personalDetails = new JLabel("Page 1: Personal Details");
        personalDetails.setFont(new Font("Raleway", Font.BOLD, 22));
        personalDetails.setForeground(Color.WHITE);
        personalDetails.setBounds(290, 80, 400, 30);
        backgroundPanel.add(personalDetails);

        // Name
        name = new JLabel("Name:");
        name.setFont(new Font("Raleway", Font.BOLD, 20));
        name.setForeground(Color.WHITE);
        name.setBounds(100, 140, 100, 30);
        backgroundPanel.add(name);

        nameTextField = new JTextField();
        nameTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        nameTextField.setBounds(300, 140, 400, 30);
        backgroundPanel.add(nameTextField);

        // Father's Name
        fname = new JLabel("Father's Name:");
        fname.setFont(new Font("Raleway", Font.BOLD, 20));
        fname.setForeground(Color.WHITE);
        fname.setBounds(100, 190, 200, 30);
        backgroundPanel.add(fname);

        fnameTextField = new JTextField();
        fnameTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        fnameTextField.setBounds(300, 190, 400, 30);
        backgroundPanel.add(fnameTextField);

        // DOB
        dob = new JLabel("Date of Birth:");
        dob.setFont(new Font("Raleway", Font.BOLD, 20));
        dob.setForeground(Color.WHITE);
        dob.setBounds(100, 240, 200, 30);
        backgroundPanel.add(dob);

        dateChooser = new JDateChooser();
        dateChooser.setBounds(300, 240, 400, 30);
        backgroundPanel.add(dateChooser);

        // Gender
        gender = new JLabel("Gender:");
        gender.setFont(new Font("Raleway", Font.BOLD, 20));
        gender.setForeground(Color.WHITE);
        gender.setBounds(100, 290, 200, 30);
        backgroundPanel.add(gender);

        male = new JRadioButton("Male");
        male.setBounds(300, 290, 60, 30);
        female = new JRadioButton("Female");
        female.setBounds(450, 290, 70, 30);
        for (JRadioButton btn : new JRadioButton[]{male, female}) {
            btn.setForeground(Color.WHITE);
            btn.setOpaque(false);
            backgroundPanel.add(btn);
        }
        gendergroup = new ButtonGroup();
        gendergroup.add(male);
        gendergroup.add(female);

        // Email
        email = new JLabel("Email Address:");
        email.setFont(new Font("Raleway", Font.BOLD, 20));
        email.setForeground(Color.WHITE);
        email.setBounds(100, 340, 200, 30);
        backgroundPanel.add(email);

        emailTextField = new JTextField();
        emailTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        emailTextField.setBounds(300, 340, 400, 30);
        backgroundPanel.add(emailTextField);

        // Marital Status
        marital = new JLabel("Marital Status:");
        marital.setFont(new Font("Raleway", Font.BOLD, 20));
        marital.setForeground(Color.WHITE);
        marital.setBounds(100, 390, 200, 30);
        backgroundPanel.add(marital);

        married = new JRadioButton("Married");
        unmarried = new JRadioButton("Unmarried");
        other = new JRadioButton("Other");
        JRadioButton[] maritalOptions = {married, unmarried, other};
        int[] positions = {300, 450, 630};
        for (int i = 0; i < maritalOptions.length; i++) {
            maritalOptions[i].setBounds(positions[i], 390, 100, 30);
            maritalOptions[i].setForeground(Color.WHITE);
            maritalOptions[i].setOpaque(false);
            backgroundPanel.add(maritalOptions[i]);
        }
        Maritalgroup = new ButtonGroup();
        Maritalgroup.add(married);
        Maritalgroup.add(unmarried);
        Maritalgroup.add(other);

        // Address
        address = new JLabel("Address:");
        address.setFont(new Font("Raleway", Font.BOLD, 20));
        address.setForeground(Color.WHITE);
        address.setBounds(100, 440, 200, 30);
        backgroundPanel.add(address);

        addressTextField = new JTextField();
        addressTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        addressTextField.setBounds(300, 440, 400, 30);
        backgroundPanel.add(addressTextField);

        // City
        city = new JLabel("City:");
        city.setFont(new Font("Raleway", Font.BOLD, 20));
        city.setForeground(Color.WHITE);
        city.setBounds(100, 490, 200, 30);
        backgroundPanel.add(city);

        cityTextField = new JTextField();
        cityTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        cityTextField.setBounds(300, 490, 400, 30);
        backgroundPanel.add(cityTextField);

        // State
        state = new JLabel("State:");
        state.setFont(new Font("Raleway", Font.BOLD, 20));
        state.setForeground(Color.WHITE);
        state.setBounds(100, 540, 200, 30);
        backgroundPanel.add(state);

        stateTextField = new JTextField();
        stateTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        stateTextField.setBounds(300, 540, 400, 30);
        backgroundPanel.add(stateTextField);

        // Pincode
        pincode = new JLabel("Pin Code:");
        pincode.setFont(new Font("Raleway", Font.BOLD, 20));
        pincode.setForeground(Color.WHITE);
        pincode.setBounds(100, 590, 200, 30);
        backgroundPanel.add(pincode);

        pincodeTextField = new JTextField();
        pincodeTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        pincodeTextField.setBounds(300, 590, 400, 30);
        backgroundPanel.add(pincodeTextField);

        // Next button
        next = new JButton("Next");
        next.setBounds(620, 660, 80, 30);
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway", Font.BOLD, 14));
        next.addActionListener(this);
        backgroundPanel.add(next);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String formno = "" + random;
        String name = nameTextField.getText();
        String fname = fnameTextField.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = male.isSelected() ? "Male" : (female.isSelected() ? "Female" : "");
        String email = emailTextField.getText();
        String marital = married.isSelected() ? "Married" : (unmarried.isSelected() ? "Unmarried" : other.isSelected() ? "Other" : "");
        String address = addressTextField.getText();
        String City = cityTextField.getText();
        String State = stateTextField.getText();
        String Pincode = pincodeTextField.getText();

        try {
            if (name.equals("")) {
                JOptionPane.showMessageDialog(null, "Name is Required");
            } else {
                Conn c = new Conn();
                String query = "insert into signup values('" + formno + "','" + name + "','" + fname + "','" + dob + "','" + gender + "','" + email + "','" + marital + "','" + address + "','" + City + "','" + State + "','" + Pincode + "')";
                c.s.executeUpdate(query);
                setVisible(false);
                new SignupTwo(formno).setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new SignupOne();
    }
}