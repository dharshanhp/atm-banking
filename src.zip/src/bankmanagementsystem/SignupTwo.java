

package bankmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignupTwo extends JFrame implements ActionListener {

    JLabel pincode, state, city, address, additionalDetails,
            marital, name, fname, dob, gender, email;
    JTextField pan, aadhar;
    JComboBox occupation, category, religion, income, education;
    JRadioButton sno, syes, eno, eyes;
    ButtonGroup citizen, account;
    JButton next;
    String formno;

    SignupTwo(String formno) {
        this.formno = formno;
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");
        setSize(850, 800);
        setLocationRelativeTo(null); // Center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load and set dynamic background panel
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/pexels-marcial-comeron-177639337-11952303.jpg"));
        Image img = icon.getImage();
        BackgroundPanel background = new BackgroundPanel(img);
        background.setLayout(null); // Absolute positioning
        setContentPane(background); // Set custom panel as content pane

        // Add components to background
        additionalDetails = new JLabel("Page 2: Additional Details");
        additionalDetails.setFont(new Font("Raleway", Font.BOLD, 22));
        additionalDetails.setBounds(290, 80, 400, 30);
        additionalDetails.setForeground(Color.white);
        background.add(additionalDetails);

        name = new JLabel("Religion:");
        name.setFont(new Font("Raleway", Font.BOLD, 20));
        name.setBounds(100, 140, 100, 30);
        name.setForeground(Color.white);
        background.add(name);

        String valReligion[] = {"Hindu", "Muslim", "Sikh", "Christian", "Other"};
        religion = new JComboBox(valReligion);
        religion.setBounds(300, 140, 400, 30);
        religion.setBackground(Color.white);
        background.add(religion);

        fname = new JLabel("Category:");
        fname.setFont(new Font("Raleway", Font.BOLD, 20));
        fname.setBounds(100, 190, 200, 30);
        fname.setForeground(Color.white);
        background.add(fname);

        String valCategory[] = {"General", "OBC", "Sc", "ST", "Other"};
        category = new JComboBox(valCategory);
        category.setBounds(300, 190, 400, 30);
        category.setBackground(Color.white);
        background.add(category);

        dob = new JLabel("Income:");
        dob.setFont(new Font("Raleway", Font.BOLD, 20));
        dob.setForeground(Color.white);
        dob.setBounds(100, 240, 200, 30);
        background.add(dob);

        String incomeCategory[] = {"Null", "< 1,50,000", "<2,50,000", "<5,00,000", "Upto 10,00,0000"};
        income = new JComboBox(incomeCategory);
        income.setBounds(300, 240, 400, 30);
        income.setBackground(Color.white);
        background.add(income);

        gender = new JLabel("Educational");
        gender.setFont(new Font("Raleway", Font.BOLD, 20));
        gender.setBounds(100, 290, 200, 30);
        gender.setForeground(Color.white);
        background.add(gender);

        email = new JLabel("Qualification:");
        email.setFont(new Font("Raleway", Font.BOLD, 20));
        email.setForeground(Color.white);
        email.setBounds(100, 315, 200, 30);
        background.add(email);

        String educationValues[] = {"Non-Graduation", "Graduation", "Post-Graduation", "Doctorate", "Others"};
        education = new JComboBox(educationValues);
        education.setBounds(300, 315, 400, 30);
        education.setBackground(Color.white);
        background.add(education);

        marital = new JLabel("Occupation:");
        marital.setFont(new Font("Raleway", Font.BOLD, 20));
        marital.setBounds(100, 390, 200, 30);
        marital.setForeground(Color.white);
        background.add(marital);

        String occupationalValues[] = {"Salaried", "Self-Employed", "Business", "Student", "Retired", "Others"};
        occupation = new JComboBox(occupationalValues);
        occupation.setBounds(300, 390, 400, 30);
        occupation.setBackground(Color.white);
        background.add(occupation);

        address = new JLabel("PAN NUMBER:");
        address.setFont(new Font("Raleway", Font.BOLD, 20));
        address.setBounds(100, 440, 200, 30);
        address.setForeground(Color.white);
        background.add(address);

        pan = new JTextField();
        pan.setFont(new Font("Raleway", Font.BOLD, 14));
        pan.setBounds(300, 440, 400, 30);
        background.add(pan);

        city = new JLabel("Aadhar Number:");
        city.setFont(new Font("Raleway", Font.BOLD, 20));
        city.setForeground(Color.white);
        city.setBounds(100, 490, 200, 30);
        background.add(city);

        aadhar = new JTextField();
        aadhar.setFont(new Font("Raleway", Font.BOLD, 14));
        aadhar.setBounds(300, 490, 400, 30);
        background.add(aadhar);

        state = new JLabel("Senior Citizen:");
        state.setFont(new Font("Raleway", Font.BOLD, 20));
        state.setForeground(Color.white);
        state.setBounds(100, 540, 200, 30);
        background.add(state);

        syes = new JRadioButton("YES");
        sno = new JRadioButton("NO");
        citizen = new ButtonGroup();
        citizen.add(syes);
        citizen.add(sno);

        syes.setBounds(300, 540, 100, 30);
        sno.setBounds(450, 540, 100, 30);
        for (JRadioButton rb : new JRadioButton[]{syes, sno}) {
            rb.setOpaque(false);
            rb.setForeground(Color.white);
            background.add(rb);
        }

        pincode = new JLabel("Existing Account:");
        pincode.setFont(new Font("Raleway", Font.BOLD, 20));
        pincode.setForeground(Color.white);
        pincode.setBounds(100, 590, 200, 30);
        background.add(pincode);

        eyes = new JRadioButton("YES");
        eno = new JRadioButton("NO");
        account = new ButtonGroup();
        account.add(eyes);
        account.add(eno);

        eyes.setBounds(300, 590, 100, 30);
        eno.setBounds(450, 590, 100, 30);
        for (JRadioButton rb : new JRadioButton[]{eyes, eno}) {
            rb.setOpaque(false);
            rb.setForeground(Color.white);
            background.add(rb);
        }

        next = new JButton("Next");
        next.setBounds(620, 660, 80, 30);
        next.setBackground(Color.black);
        next.setForeground(Color.white);
        next.setFont(new Font("Raleway", Font.BOLD, 14));
        next.addActionListener(this);
        background.add(next);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String sreligion = (String) religion.getSelectedItem();
        String scategory = (String) category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String seducation = (String) education.getSelectedItem();
        String soccupation = (String) occupation.getSelectedItem();
        String seniorcitizen = syes.isSelected() ? "Yes" : "No";
        String existingaccount = eyes.isSelected() ? "Yes" : "No";
        String span = pan.getText();
        String saddhar = aadhar.getText();
        try {
            Conn c = new Conn();
            String query = "insert into signuptwo values('" + formno + "','" + sreligion + "','" + scategory + "','" + sincome + "','" + seducation + "','" + soccupation + "','" + span + "','" + saddhar + "','" + seniorcitizen + "','" + existingaccount + "')";
            c.s.executeUpdate(query);
            setVisible(false);
            new SignupThree(formno).setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new SignupTwo("");
    }
}

// ✅ Flexible Background Panel
class BackgroundPanel extends JPanel {
    private Image backgroundImage;
    public BackgroundPanel(Image backgroundImage) {
        this.backgroundImage = backgroundImage;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw image to fit the panel dynamically
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}