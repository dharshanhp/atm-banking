
package bankmanagementsystem;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class SignupThree extends JFrame implements ActionListener {

    JRadioButton r1, r2, r3, r4;
    JCheckBox c1, c2, c3, c4, c5, c6, c7;
    JButton submit, Cancel;
    String formno;

    SignupThree(String formno) {
        this.formno = formno;
        setLayout(null);
        setResizable(true); // Make frame resizable

        // Load background image
        ImageIcon backgroundImg = new ImageIcon(ClassLoader.getSystemResource("icons/pexels-coincloud-6132767.jpg"));

        // Create a JLabel with dynamic background drawing
        JLabel background = new JLabel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImg.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        background.setLayout(null);
        background.setBounds(0, 0, 850, 820);
        add(background);

        // Repaint background on resize
        this.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                background.setSize(getWidth(), getHeight());
                background.repaint();
            }
        });

        JLabel l1 = new JLabel("Page 3: Account Details");
        l1.setFont(new Font("Raleway", Font.BOLD, 22));
        l1.setForeground(Color.white);
        l1.setBounds(280, 40, 400, 40);
        background.add(l1);

        JLabel type = new JLabel("Account Type");
        type.setFont(new Font("Raleway", Font.BOLD, 22));
        type.setForeground(Color.white);
        type.setBounds(100, 140, 200, 30);
        background.add(type);

        r1 = new JRadioButton("Saving Account");
        r2 = new JRadioButton("Fixed Deposit Account");
        r3 = new JRadioButton("Current Account");
        r4 = new JRadioButton("Recurring Deposit Account");
        JRadioButton[] radios = {r1, r2, r3, r4};

        int[] rx = {100, 350, 100, 350};
        int[] ry = {180, 180, 220, 220};

        for (int i = 0; i < radios.length; i++) {
            radios[i].setBounds(rx[i], ry[i], 250, 20);
            radios[i].setFont(new Font("Raleway", Font.BOLD, 16));
            radios[i].setOpaque(false);
            radios[i].setForeground(Color.white);
            background.add(radios[i]);
        }

        ButtonGroup groupaccount = new ButtonGroup();
        for (JRadioButton r : radios) groupaccount.add(r);

        JLabel card = new JLabel("Card Number");
        card.setFont(new Font("Raleway", Font.BOLD, 22));
        card.setForeground(Color.white);
        card.setBounds(100, 300, 200, 30);
        background.add(card);

        JLabel Number = new JLabel("XXXX-XXXX-XXXX-4184");
        Number.setFont(new Font("Raleway", Font.BOLD, 22));
        Number.setForeground(Color.white);
        Number.setBounds(330, 300, 300, 30);
        background.add(Number);

        JLabel cardDetails = new JLabel("Your 16 Digit Card Number");
        cardDetails.setFont(new Font("Raleway", Font.BOLD, 12));
        cardDetails.setForeground(Color.white);
        cardDetails.setBounds(100, 330, 300, 20);
        background.add(cardDetails);

        JLabel pin = new JLabel("PIN:");
        pin.setFont(new Font("Raleway", Font.BOLD, 22));
        pin.setForeground(Color.white);
        pin.setBounds(100, 370, 200, 30);
        background.add(pin);

        JLabel pNumber = new JLabel("XXXX");
        pNumber.setFont(new Font("Raleway", Font.BOLD, 22));
        pNumber.setForeground(Color.white);
        pNumber.setBounds(330, 370, 300, 30);
        background.add(pNumber);

        JLabel pinDetails = new JLabel("Your 4 Digit Password");
        pinDetails.setFont(new Font("Raleway", Font.BOLD, 12));
        pinDetails.setForeground(Color.white);
        pinDetails.setBounds(100, 400, 300, 20);
        background.add(pinDetails);

        JLabel services = new JLabel("Services Required");
        services.setFont(new Font("Raleway", Font.BOLD, 22));
        services.setForeground(Color.white);
        services.setBounds(100, 450, 200, 30);
        background.add(services);

        c1 = new JCheckBox("ATM CARD");
        c2 = new JCheckBox("Internet Banking");
        c3 = new JCheckBox("Mobile Banking");
        c4 = new JCheckBox("Email & SMS Alerts");
        c5 = new JCheckBox("Cheque Book");
        c6 = new JCheckBox("E-Statement");
        c7 = new JCheckBox("I hereby declare that the above entered details are correct to the best of my knowledge");

        JCheckBox[] checks = {c1, c2, c3, c4, c5, c6};
        int[] cx = {100, 350, 100, 350, 100, 350};
        int[] cy = {500, 500, 550, 550, 600, 600};

        for (int i = 0; i < checks.length; i++) {
            checks[i].setBounds(cx[i], cy[i], 250, 30);
            checks[i].setFont(new Font("Raleway", Font.BOLD, 16));
            checks[i].setOpaque(false);
            checks[i].setForeground(Color.white);
            background.add(checks[i]);
        }

        c7.setFont(new Font("Raleway", Font.BOLD, 12));
        c7.setBounds(100, 680, 600, 30);
        c7.setOpaque(false);
        c7.setForeground(Color.white);
        background.add(c7);

        submit = new JButton("Submit");
        submit.setBounds(250, 720, 100, 30);
        submit.setFont(new Font("Raleway", Font.BOLD, 14));
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        background.add(submit);

        Cancel = new JButton("Cancel");
        Cancel.setBounds(420, 720, 100, 30);
        Cancel.setFont(new Font("Raleway", Font.BOLD, 14));
        Cancel.setBackground(Color.black);
        Cancel.setForeground(Color.white);
        Cancel.addActionListener(this);
        background.add(Cancel);

        getContentPane().setBackground(Color.white);
        setSize(850, 820);
        setLocation(350, 0);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submit) {
            String accountType = null;
            if (r1.isSelected()) accountType = "Saving Account";
            else if (r2.isSelected()) accountType = "Fixed Deposit Account";
            else if (r3.isSelected()) accountType = "Current Account";
            else if (r4.isSelected()) accountType = "Recurring Deposit Account";

            Random random = new Random();
            String cardnumber = "" + Math.abs((random.nextLong() % 90000000L) + 50409360000000L);
            String pinnumber = "" + Math.abs((random.nextLong() % 9000L) + 1000L);

            String facility = "";
            if (c1.isSelected()) facility += " ATM Card";
            if (c2.isSelected()) facility += " Internet Banking";
            if (c3.isSelected()) facility += " Mobile Banking";
            if (c4.isSelected()) facility += " Email & SMS Alerts";
            if (c5.isSelected()) facility += " Cheque Book";
            if (c6.isSelected()) facility += " E-Statement";

            try {
                if (accountType == null) {
                    JOptionPane.showMessageDialog(null, "Account Type Required");
                } else {
                    Conn conn = new Conn();
                    String query1 = "insert into signupthree values('" + formno + "','" + accountType + "','" + cardnumber + "','" + pinnumber + "','" + facility + "')";
                    String query2 = "insert into login values('" + formno + "','" + cardnumber + "','" + pinnumber + "')";
                    conn.s.executeUpdate(query1);
                    conn.s.executeUpdate(query2);
                    JOptionPane.showMessageDialog(null, "Card Number: " + cardnumber + "\n Pin: " + pinnumber);
                    setVisible(false);
                    new Deposit(pinnumber).setVisible(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == Cancel) {
            setVisible(false);
            new Login().setVisible(true);
        }
    }

    public static void main(String args[]) {
        new SignupThree("");
    }
}
