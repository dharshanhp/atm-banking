package bankmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class Login extends JFrame implements ActionListener {
    JButton login, clear, signup;
    JTextField cardTextField;
    JPasswordField pinTextField;
    JLabel label, text, cardno, pin;
    BackgroundPanel backgroundPanel;
    Timer sliderTimer;

    Login() {
        setTitle("AUTOMATED TELLER MACHINE");

        // Background image paths
        ArrayList<String> bgImages = new ArrayList<>();
        bgImages.add("icons/pexels-coincloud-6132766.jpg");
        bgImages.add("icons/pexels-coincloud-6132774.jpg");
        bgImages.add("icons/pexels-pixabay-50987.jpg");
        bgImages.add("icons/pexels-jan-van-der-wolf-11680885-7545104.jpg");
        bgImages.add("icons/pexels-alesiakozik-6781340.jpg");

        // Background panel
        backgroundPanel = new BackgroundPanel(bgImages);
        backgroundPanel.setLayout(null);
        add(backgroundPanel);

        // Logo
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        label = new JLabel(new ImageIcon(i2));
        backgroundPanel.add(label);

        // Welcome text
        text = new JLabel("Welcome to ATM");
        text.setFont(new Font("Verdana", Font.BOLD, 30));
        text.setForeground(Color.WHITE);
        backgroundPanel.add(text);

        // Card No.
        cardno = new JLabel("Card No.");
        cardno.setFont(new Font("SansSerif", Font.BOLD, 26));
        cardno.setForeground(Color.WHITE);
        backgroundPanel.add(cardno);

        cardTextField = new JTextField();
        cardTextField.setFont(new Font("Arial", Font.PLAIN, 16));
        backgroundPanel.add(cardTextField);

        // PIN
        pin = new JLabel("PIN");
        pin.setFont(new Font("SansSerif", Font.BOLD, 26));
        pin.setForeground(Color.WHITE);
        backgroundPanel.add(pin);

        pinTextField = new JPasswordField();
        pinTextField.setFont(new Font("Arial", Font.PLAIN, 16));
        backgroundPanel.add(pinTextField);

        // Buttons
        login = new JButton("SIGN IN");
        styleButton(login);
        backgroundPanel.add(login);
        login.addActionListener(this);

        clear = new JButton("CLEAR");
        styleButton(clear);
        backgroundPanel.add(clear);
        clear.addActionListener(this);

        signup = new JButton("SIGN UP");
        styleButton(signup);
        backgroundPanel.add(signup);
        signup.addActionListener(this);

        // Resize listener
        addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                repositionComponents();
            }
        });

        // JFrame settings
        setSize(800, 500);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        repositionComponents();

        // Background slider timer
        sliderTimer = new Timer(4000, e -> {
            backgroundPanel.nextImage();
            backgroundPanel.repaint();
        });
        sliderTimer.start();
    }

    // Reposition all components
    private void repositionComponents() {
        int w = getWidth();
        int h = getHeight();
        label.setBounds(w / 15, h / 20, 100, 100);
        text.setBounds(w / 4, h / 10, 400, 40);
        cardno.setBounds(w / 8, h / 3, 150, 30);
        cardTextField.setBounds(w / 3, h / 3, 250, 30);
        pin.setBounds(w / 8, h / 2, 150, 30);
        pinTextField.setBounds(w / 3, h / 2, 250, 30);
        login.setBounds(w / 3, h / 2 + 60, 100, 30);
        clear.setBounds(w / 3 + 130, h / 2 + 60, 100, 30);
        signup.setBounds(w / 3, h / 2 + 110, 230, 30);
    }

    // Style buttons
    private void styleButton(JButton btn) {
        btn.setBackground(Color.BLACK);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(Color.WHITE));
    }

    // Button action handlers
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == clear) {
            cardTextField.setText("");
            pinTextField.setText("");
        } else if (ae.getSource() == login) {
            Conn conn = new Conn();
            String cardnumber = cardTextField.getText();
            String pinnumber = pinTextField.getText();
            String query = "SELECT * FROM login WHERE cardnumber ='" + cardnumber + "' AND pin = '" + pinnumber + "'";
            try {
                ResultSet rs = conn.s.executeQuery(query);
                if (rs.next()) {
                    setVisible(false);
                    new Transactions(pinnumber).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect Card Number or PIN");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == signup) {
            setVisible(false);
            new SignupOne().setVisible(true);
        }
    }

    // Background panel with slider support
    class BackgroundPanel extends JPanel {
        private ArrayList<Image> images;
        private int currentImageIndex = 0;

        public BackgroundPanel(ArrayList<String> imagePaths) {
            images = new ArrayList<>();
            for (String path : imagePaths) {
                try {
                    Image img = new ImageIcon(ClassLoader.getSystemResource(path)).getImage();
                    images.add(img);
                } catch (Exception e) {
                    System.out.println("Image not found: " + path);
                }
            }
        }

        public void nextImage() {
            currentImageIndex = (currentImageIndex + 1) % images.size();
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (!images.isEmpty()) {
                Image bg = images.get(currentImageIndex);
                g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}